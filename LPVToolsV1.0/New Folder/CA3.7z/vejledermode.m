x_dt=A*x+a
stationary=A*x0+(a0=0)
pertubation_an=x=x0+dx
delta_x_dt=A*(x0+delta_x)+a
delta_x_dt=A*(x0+delta_x)+a