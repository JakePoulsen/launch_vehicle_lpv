function handle = CodeImporter(blockName,fileName)
    open_system(gcs+".slx");
    blockPath = gcs+"/"+blockName;
    handle= getSimulinkBlockHandle(blockPath);
    sf = sfroot();
    block = sf.find('Path',blockPath,'-isa','Stateflow.EMChart');
    block.Script = fileread(fileName);
end